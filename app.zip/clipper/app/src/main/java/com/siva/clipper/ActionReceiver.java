package com.siva.clipper;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.io.File;

/** Handles the "Skip" button: deletes the clip and clears its notification. */
public class ActionReceiver extends BroadcastReceiver {
    static final String ACTION_SKIP = "com.siva.clipper.SKIP";

    @Override
    public void onReceive(Context c, Intent i) {
        if (!ACTION_SKIP.equals(i.getAction())) return;
        String path = i.getStringExtra(ShareActivity.EXTRA_PATH);
        if (path != null) new File(path).delete();
        int notif = i.getIntExtra(ShareActivity.EXTRA_NOTIF, 0);
        if (notif != 0) c.getSystemService(NotificationManager.class).cancel(notif);
    }
}
