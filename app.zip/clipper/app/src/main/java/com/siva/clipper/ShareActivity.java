package com.siva.clipper;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;

/** Invisible screen opened by the "Send to Gemini" button: hands the clip to Gemini and closes. */
public class ShareActivity extends Activity {
    static final String EXTRA_PATH = "path";
    static final String EXTRA_NOTIF = "notif";
    static final String GEMINI = "com.google.android.apps.bard";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String path = getIntent().getStringExtra(EXTRA_PATH);
        int notif = getIntent().getIntExtra(EXTRA_NOTIF, 0);
        if (notif != 0) getSystemService(NotificationManager.class).cancel(notif);
        if (path != null) sendToGemini(this, new File(path));
        finish();
    }

    static void sendToGemini(Activity a, File clip) {
        if (!clip.exists()) {
            Toast.makeText(a, "That clip no longer exists", Toast.LENGTH_SHORT).show();
            return;
        }
        String prompt = Prefs.prompt(a);
        // Backup: if Gemini ignores the attached text, the prompt is ready to paste.
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Clipper prompt", prompt));

        Uri uri = FileProvider.getUriForFile(a, "com.siva.clipper.files", clip);
        Intent send = new Intent(Intent.ACTION_SEND)
                .setType("audio/mp4")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, prompt)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        send.setClipData(ClipData.newRawUri("clip", uri));

        try {
            a.startActivity(new Intent(send).setPackage(GEMINI));
        } catch (ActivityNotFoundException e) {
            // Gemini didn't accept a direct share; let the user pick it from the share sheet.
            a.startActivity(Intent.createChooser(send, "Send clip to…")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        }
    }
}
