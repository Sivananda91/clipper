package com.siva.clipper;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private TextView statusView;
    private Button toggle;
    private Button batteryBtn;
    private EditText promptBox;
    private LinearLayout clipList;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean wantStart = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refreshStatus();
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        RecorderService.createChannels(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(statusView);

        toggle = new Button(this);
        toggle.setOnClickListener(v -> onToggle());
        root.addView(toggle);

        batteryBtn = new Button(this);
        batteryBtn.setText("Allow running in background (do once)");
        batteryBtn.setOnClickListener(v -> askBatteryExemption());
        root.addView(batteryBtn);

        root.addView(heading("Sensitivity"));
        root.addView(radio(new String[]{"Low (close, clear voices)", "Medium", "High (quieter voices)"},
                Prefs.sensitivity(this), i -> Prefs.setSensitivity(this, i)));

        root.addView(heading("A conversation ends after this much silence"));
        final int[] gaps = {60, 90, 120, 180};
        root.addView(radio(new String[]{"1 min", "1.5 min", "2 min", "3 min"},
                indexOf(gaps, Prefs.gapSeconds(this), 1), i -> Prefs.setGapSeconds(this, gaps[i])));

        root.addView(heading("Longest clip (minutes of speech)"));
        final int[] maxes = {5, 10, 15, 20};
        root.addView(radio(new String[]{"5", "10", "15", "20"},
                indexOf(maxes, Prefs.maxClipMinutes(this), 1), i -> Prefs.setMaxClipMinutes(this, maxes[i])));

        root.addView(heading("Prompt sent to Gemini with each clip"));
        promptBox = new EditText(this);
        promptBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        promptBox.setMinLines(3);
        promptBox.setText(Prefs.prompt(this));
        root.addView(promptBox);
        Button reset = new Button(this);
        reset.setText("Reset prompt");
        reset.setOnClickListener(v -> promptBox.setText(Prefs.DEFAULT_PROMPT));
        root.addView(reset);

        root.addView(heading("Clips waiting"));
        clipList = new LinearLayout(this);
        clipList.setOrientation(LinearLayout.VERTICAL);
        root.addView(clipList);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshClips();
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
        Prefs.setPrompt(this, promptBox.getText().toString().trim().isEmpty()
                ? Prefs.DEFAULT_PROMPT : promptBox.getText().toString());
    }

    // ------------------------------------------------------------- start / stop

    private void onToggle() {
        if (RecorderService.running) {
            startService(new Intent(this, RecorderService.class).setAction(RecorderService.ACTION_STOP));
            return;
        }
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) {
            wantStart = true;
            requestPermissions(need.toArray(new String[0]), 1);
            return;
        }
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (!wantStart) return;
        wantStart = false;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else {
            statusView.setText("Microphone permission is needed to listen");
        }
    }

    private void startListening() {
        startForegroundService(new Intent(this, RecorderService.class).setAction(RecorderService.ACTION_START));
        RecorderService.status = "Starting…";
        refreshStatus();
    }

    private void askBatteryExemption() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void refreshStatus() {
        statusView.setText(RecorderService.status);
        toggle.setText(RecorderService.running ? "Stop listening" : "Start listening");
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        batteryBtn.setVisibility(pm.isIgnoringBatteryOptimizations(getPackageName()) ? View.GONE : View.VISIBLE);
        if (clipList.getChildCount() != countClips()) refreshClips();
    }

    // -------------------------------------------------------------------- clips

    private File[] clips() {
        File[] files = Prefs.clipsDir(this).listFiles((d, n) -> n.endsWith(".m4a"));
        if (files == null) return new File[0];
        Arrays.sort(files, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        return files;
    }

    private int countClips() {
        int n = clips().length;
        return n == 0 ? 1 : n + 1; // +1 for the "none"/"delete all" row
    }

    private void refreshClips() {
        clipList.removeAllViews();
        File[] files = clips();
        if (files.length == 0) {
            TextView none = new TextView(this);
            none.setText("None. New clips also appear as notifications.");
            clipList.addView(none);
            return;
        }
        for (File f : files) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView name = new TextView(this);
            name.setText(pretty(f) + "  (" + (f.length() / 1024) + " KB)");
            row.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button send = new Button(this);
            send.setText("Send");
            send.setOnClickListener(v -> ShareActivity.sendToGemini(this, f));
            row.addView(send);

            Button del = new Button(this);
            del.setText("Delete");
            del.setOnClickListener(v -> { f.delete(); refreshClips(); });
            row.addView(del);

            clipList.addView(row);
        }
        Button all = new Button(this);
        all.setText("Delete all clips");
        all.setOnClickListener(v -> {
            for (File f : clips()) f.delete();
            refreshClips();
        });
        clipList.addView(all);
    }

    /** clip_20261019_1042.m4a -> 19-10 10:42 */
    private static String pretty(File f) {
        String n = f.getName();
        try {
            return n.substring(11, 13) + "-" + n.substring(9, 11) + "  " + n.substring(14, 16) + ":" + n.substring(16, 18);
        } catch (Exception e) {
            return n;
        }
    }

    // ---------------------------------------------------------------- UI helpers

    interface Pick { void on(int i); }

    private TextView heading(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(4));
        return t;
    }

    private RadioGroup radio(String[] labels, int selected, Pick pick) {
        RadioGroup g = new RadioGroup(this);
        for (int i = 0; i < labels.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(View.generateViewId());
            r.setText(labels[i]);
            final int idx = i;
            r.setOnCheckedChangeListener((btn, on) -> { if (on) pick.on(idx); });
            g.addView(r);
            if (i == selected) r.setChecked(true);
        }
        return g;
    }

    private static int indexOf(int[] arr, int v, int fallback) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return fallback;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
