package com.siva.clipper;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;

/** Small settings store shared by the app's screens and the recorder. */
final class Prefs {
    static final String DEFAULT_PROMPT =
            "Transcribe this office conversation (it may mix English, Telugu and Hindi). "
            + "Then list every commitment, follow-up, deadline and request: "
            + "who said it, what exactly, to whom, and by when. "
            + "If nothing actionable was said, just say so.";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("clipper", Context.MODE_PRIVATE);
    }

    /** 0 = low (only clear, close speech), 1 = medium, 2 = high (picks up quieter voices). */
    static int sensitivity(Context c) { return sp(c).getInt("sens", 1); }
    static void setSensitivity(Context c, int v) { sp(c).edit().putInt("sens", v).apply(); }

    /** Silence (seconds) that ends a conversation and closes the clip. */
    static int gapSeconds(Context c) { return sp(c).getInt("gap", 90); }
    static void setGapSeconds(Context c, int v) { sp(c).edit().putInt("gap", v).apply(); }

    /** Longest clip, in minutes of actual speech, before it is closed anyway. */
    static int maxClipMinutes(Context c) { return sp(c).getInt("maxmin", 10); }
    static void setMaxClipMinutes(Context c, int v) { sp(c).edit().putInt("maxmin", v).apply(); }

    static String prompt(Context c) { return sp(c).getString("prompt", DEFAULT_PROMPT); }
    static void setPrompt(Context c, String v) { sp(c).edit().putString("prompt", v).apply(); }

    static File clipsDir(Context c) {
        File d = new File(c.getFilesDir(), "clips");
        if (!d.exists()) d.mkdirs();
        return d;
    }
}
