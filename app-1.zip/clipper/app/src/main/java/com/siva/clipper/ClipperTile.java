package com.siva.clipper;

import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/**
 * Quick Settings tile.
 *  Off      → tap opens Clipper and starts listening.
 *  Running  → tap pauses for 30 min / resumes.
 *  Long-press opens the app.
 */
public class ClipperTile extends TileService {

    @Override
    public void onStartListening() {
        update();
    }

    @Override
    public void onClick() {
        if (RecorderService.running) {
            boolean paused = System.currentTimeMillis() < RecorderService.pausedUntil;
            startService(new Intent(this, RecorderService.class)
                    .setAction(paused ? RecorderService.ACTION_RESUME : RecorderService.ACTION_PAUSE));
            // Reflect the change right away; the service refreshes it again shortly.
            RecorderService.pausedUntil = paused ? 0 : System.currentTimeMillis() + RecorderService.PAUSE_MS;
            update();
        } else {
            // Android only lets the mic start from a visible screen, so open the app to start.
            Intent open = new Intent(this, MainActivity.class)
                    .putExtra(MainActivity.EXTRA_AUTOSTART, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 20, open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            } else {
                startActivityAndCollapse(open);
            }
        }
    }

    private void update() {
        Tile t = getQsTile();
        if (t == null) return;
        boolean running = RecorderService.running;
        boolean paused = running && System.currentTimeMillis() < RecorderService.pausedUntil;
        t.setIcon(Icon.createWithResource(this, R.drawable.ic_stat_clipper));
        t.setLabel("Clipper");
        if (!running) {
            t.setState(Tile.STATE_INACTIVE);
            t.setSubtitle("Off");
        } else if (paused) {
            t.setState(Tile.STATE_INACTIVE);
            t.setSubtitle("Paused");
        } else {
            t.setState(Tile.STATE_ACTIVE);
            t.setSubtitle(RecorderService.state == RecorderService.State.ARMED ? "Ready" : "Listening");
        }
        t.updateTile();
    }
}
