package com.siva.clipper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Scrolling bar meter: teal bars = voice, grey = other sound. */
class LevelView extends View {
    private static final int N = 48;
    private final float[] levels = new float[N];
    private final int[] kinds = new int[N]; // 0 quiet, 1 noise, 2 voice
    private int head = 0;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    LevelView(Context c) { super(c); }

    void push(float level, boolean voice, boolean noise) {
        levels[head] = level;
        kinds[head] = voice ? 2 : noise ? 1 : 0;
        head = (head + 1) % N;
        invalidate();
    }

    void clear() {
        for (int i = 0; i < N; i++) { levels[i] = 0; kinds[i] = 0; }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float slot = w / N;
        float bar = slot * 0.6f;
        float mid = h / 2f;
        for (int i = 0; i < N; i++) {
            int idx = (head + i) % N;
            float lv = Math.max(0.04f, levels[idx]);
            float half = lv * h / 2f;
            int k = kinds[idx];
            paint.setColor(k == 2 ? Ui.ACCENT : k == 1 ? 0xFF5A6070 : 0xFF2C313B);
            float x = i * slot + (slot - bar) / 2f;
            r.set(x, mid - half, x + bar, mid + half);
            canvas.drawRoundRect(r, bar / 2f, bar / 2f, paint);
        }
    }
}
