package com.siva.clipper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.audiofx.NoiseSuppressor;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.service.quicksettings.TileService;
import android.util.Log;

import com.konovalov.vad.silero.VadSilero;
import com.konovalov.vad.silero.config.FrameSize;
import com.konovalov.vad.silero.config.Mode;
import com.konovalov.vad.silero.config.SampleRate;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Listens in the background. Keeps only stretches where someone is speaking, groups
 * them into one clip per conversation, and when a conversation ends (a long silence)
 * saves a small .m4a to Recordings/Clipper and shows a "Send to Gemini / Skip" notification.
 *
 * Started two ways:
 *  - ACTION_START: manual, listens until stopped.
 *  - ACTION_ARM: from the morning "Working day?" Yes; keeps audio only in office hours
 *    and switches itself off at the end of office hours.
 */
public class RecorderService extends Service {
    static final String ACTION_START = "com.siva.clipper.START";
    static final String ACTION_ARM = "com.siva.clipper.ARM";
    static final String ACTION_STOP = "com.siva.clipper.STOP";
    static final String ACTION_PAUSE = "com.siva.clipper.PAUSE";
    static final String ACTION_RESUME = "com.siva.clipper.RESUME";

    static final String CH_REC = "rec";
    static final String CH_CLIPS = "clips";
    static final int ONGOING_ID = 1;
    static final int SUMMARY_ID = 3;
    static final long PAUSE_MS = 30 * 60_000L;

    static final int SAMPLE_RATE = 16000;
    private static final int FRAME = 512;              // 32 ms at 16 kHz (what the speech model expects)
    private static final int FRAME_MS = 32;
    private static final int PREROLL_FRAMES = 31;      // ~1 s kept before speech starts
    private static final int HANGOVER_FRAMES = 47;     // ~1.5 s kept after speech stops
    private static final int TRIGGER_FRAMES = 3;       // ~100 ms of voice before we call it speech
    private static final int MIN_SPEECH_SECONDS = 3;   // clips with less real speech are thrown away
    private static final int BITRATE = 32000;          // ~14 MB per hour of speech

    // ---- live state read by the app screen and the Quick Settings tile
    enum State { OFF, ARMED, LISTENING, CAPTURING, PAUSED }
    static volatile State state = State.OFF;
    static volatile boolean running = false;
    static volatile boolean scheduled = false;
    static volatile long pausedUntil = 0;
    static volatile float level = 0f;          // 0..1 mic loudness
    static volatile boolean voiceNow = false;  // speech model hears a voice right now
    static volatile boolean noiseNow = false;  // loud, but not a voice
    static volatile long clipSeconds = 0;
    static volatile int clipsToday = 0;
    static volatile String error = null;

    private Thread worker;
    private final ExecutorService encoder = Executors.newSingleThreadExecutor();
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null && intent.getAction() != null ? intent.getAction() : ACTION_START;

        if (ACTION_STOP.equals(action)) {
            running = false;
            if (worker == null) stopSelfNow();
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action)) {
            pausedUntil = System.currentTimeMillis() + PAUSE_MS;
            refreshOngoing();
            return START_NOT_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            pausedUntil = 0;
            refreshOngoing();
            return START_NOT_STICKY;
        }

        if (ACTION_ARM.equals(action)) {
            getSystemService(NotificationManager.class).cancel(Schedule.ASK_ID);
        }

        if (worker != null) {
            // Already running: a manual start turns a scheduled run into an all-day run.
            if (ACTION_START.equals(action)) scheduled = false;
            refreshOngoing();
            return START_NOT_STICKY;
        }

        scheduled = ACTION_ARM.equals(action);
        pausedUntil = 0;
        error = null;
        try {
            startForeground(ONGOING_ID, ongoingNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } catch (Exception e) {
            error = "Android blocked the microphone. Open Clipper and tap Start.";
            stopSelf();
            return START_NOT_STICKY;
        }

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clipper:rec");
        wakeLock.acquire();

        running = true;
        state = scheduled ? State.ARMED : State.LISTENING;
        clipsToday = 0;
        worker = new Thread(this::recordLoop, "clipper-rec");
        worker.start();
        pokeTile(this);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        state = State.OFF;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        encoder.shutdown();
        pokeTile(this);
        super.onDestroy();
    }

    private void stopSelfNow() {
        state = State.OFF;
        level = 0;
        voiceNow = noiseNow = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        pokeTile(this);
    }

    // ---------------------------------------------------------------- recording

    private FileOutputStream clipOut;
    private File clipPcm;
    private long clipStartMs;
    private long clipFrames;        // frames written (speech + padding)
    private long clipSpeechFrames;  // frames judged as speech
    private long lastSpeechMs;
    private State lastNotified = null;
    private boolean lastPausedShown = false;

    private void recordLoop() {
        int minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord rec;
        try {
            rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minBuf, SAMPLE_RATE * 2));
        } catch (SecurityException e) {
            error = "Microphone permission is missing";
            running = false;
            finishLoop(false);
            return;
        }
        if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
            error = "Could not open the microphone";
            rec.release();
            running = false;
            finishLoop(false);
            return;
        }

        // Phone's built-in noise reduction, so the saved audio is cleaner for Gemini.
        NoiseSuppressor ns = null;
        try {
            if (NoiseSuppressor.isAvailable()) {
                ns = NoiseSuppressor.create(rec.getAudioSessionId());
                if (ns != null) ns.setEnabled(true);
            }
        } catch (Exception ignored) {}

        // On-device speech model: tells human voice apart from fans, typing, traffic, doors.
        VadSilero vad = null;
        int vadMode = -1;

        rec.startRecording();
        short[] frame = new short[FRAME];
        byte[] bytes = new byte[FRAME * 2];
        ArrayDeque<byte[]> preroll = new ArrayDeque<>();
        double noise = 200;
        int speechRun = 0;
        int hang = 0;
        long lastUiMs = 0;
        boolean endedByClock = false;

        while (running) {
            int n = readFully(rec, frame);
            if (n < 0) break;
            long now = System.currentTimeMillis();

            // Loudness of this 32 ms frame.
            double sum = 0;
            for (short s : frame) sum += (double) s * s;
            double rms = Math.sqrt(sum / FRAME);
            level = (float) Math.min(1.0, Math.log10(1 + rms) / 3.6);

            // ---- gates: office hours and pause
            int nowMin = Schedule.nowMinutes();
            if (scheduled && nowMin >= Prefs.officeEnd(this)) {
                endedByClock = true;
                break;
            }
            boolean paused = now < pausedUntil;
            boolean inHours = !scheduled || nowMin >= Prefs.officeStart(this);
            if (paused || !inHours) {
                if (clipOut != null) closeClip();
                preroll.clear();
                hang = 0;
                speechRun = 0;
                voiceNow = noiseNow = false;
                state = paused ? State.PAUSED : State.ARMED;
                if (now - lastUiMs > 1000) { lastUiMs = now; maybeRefresh(); }
                continue;
            }
            if (pausedUntil != 0 && !paused) pausedUntil = 0;

            int sens = Prefs.sensitivity(this);
            double mult = sens == 0 ? 3.0 : sens == 1 ? 2.0 : 1.5;
            double minAbs = sens == 0 ? 300 : sens == 1 ? 150 : 80;
            boolean loud = rms > Math.max(noise * mult, minAbs);

            if (vad == null || vadMode != sens) {
                if (vad != null) try { vad.close(); } catch (Exception ignored) {}
                vad = makeVad(sens);
                vadMode = sens;
            }
            boolean voice;
            if (vad != null) {
                try {
                    voice = loud && vad.isSpeech(frame);
                } catch (Exception e) {
                    voice = loud;
                }
            } else {
                voice = loud; // model unavailable: fall back to loudness only
            }
            voiceNow = voice;
            noiseNow = loud && !voice;

            if (!loud) {
                // Track the room's background hum so fans/AC don't count as speech.
                double rate = rms < noise ? 0.05 : 0.005;
                noise = noise * (1 - rate) + rms * rate;
                if (noise < 30) noise = 30;
            }
            speechRun = voice ? speechRun + 1 : 0;
            boolean speech = speechRun >= TRIGGER_FRAMES;

            toBytes(frame, bytes);

            if (speech) {
                hang = HANGOVER_FRAMES;
                lastSpeechMs = now;
                if (clipOut == null) openClip(now);
                if (clipOut != null) {
                    while (!preroll.isEmpty()) write(preroll.pollFirst());
                    clipSpeechFrames++;
                }
            }

            if (clipOut != null && hang > 0) {
                write(bytes);
                hang--;
            } else {
                preroll.addLast(bytes.clone());
                if (preroll.size() > PREROLL_FRAMES) preroll.pollFirst();
            }

            if (clipOut != null) {
                long gapMs = Prefs.gapSeconds(this) * 1000L;
                long maxFrames = Prefs.maxClipMinutes(this) * 60_000L / FRAME_MS;
                if ((hang == 0 && now - lastSpeechMs > gapMs) || clipFrames >= maxFrames) {
                    closeClip();
                    hang = 0;
                }
            }

            state = clipOut != null ? State.CAPTURING : State.LISTENING;
            clipSeconds = clipOut != null ? clipFrames * FRAME_MS / 1000 : 0;
            if (now - lastUiMs > 1000) { lastUiMs = now; maybeRefresh(); }
        }

        try { rec.stop(); } catch (Exception ignored) {}
        rec.release();
        if (ns != null) try { ns.release(); } catch (Exception ignored) {}
        if (vad != null) try { vad.close(); } catch (Exception ignored) {}
        running = false;
        finishLoop(endedByClock);
    }

    /** Updates the ongoing notification and tile only when something visible changed. */
    private void maybeRefresh() {
        boolean p = state == State.PAUSED;
        if (state != lastNotified || p != lastPausedShown) {
            lastNotified = state;
            lastPausedShown = p;
            refreshOngoing();
            pokeTile(this);
        }
    }

    private VadSilero makeVad(int sens) {
        Mode mode = sens == 0 ? Mode.VERY_AGGRESSIVE : sens == 1 ? Mode.AGGRESSIVE : Mode.NORMAL;
        try {
            return new VadSilero(this, SampleRate.SAMPLE_RATE_16K, FrameSize.FRAME_SIZE_512, mode, 0, 0);
        } catch (Throwable t) {
            Log.e("Clipper", "speech model unavailable", t);
            return null;
        }
    }

    /** Runs on the worker thread when listening ends. */
    private void finishLoop(boolean endedByClock) {
        closeClip();
        encoder.execute(() -> {
            worker = null;
            if (endedByClock) postSummary();
            stopSelfNow();
        });
    }

    private static int readFully(AudioRecord rec, short[] buf) {
        int off = 0;
        while (off < buf.length) {
            int n = rec.read(buf, off, buf.length - off);
            if (n < 0) return n;
            off += n;
        }
        return off;
    }

    private static void toBytes(short[] s, byte[] b) {
        for (int i = 0; i < s.length; i++) {
            b[2 * i] = (byte) (s[i] & 0xff);
            b[2 * i + 1] = (byte) ((s[i] >> 8) & 0xff);
        }
    }

    private void openClip(long now) {
        try {
            clipStartMs = now;
            clipFrames = 0;
            clipSpeechFrames = 0;
            clipPcm = new File(getCacheDir(), "clip_" + now + ".pcm");
            clipOut = new FileOutputStream(clipPcm);
        } catch (IOException e) {
            Log.e("Clipper", "open clip", e);
            clipOut = null;
        }
    }

    private void write(byte[] b) {
        try {
            clipOut.write(b);
            clipFrames++;
        } catch (IOException e) {
            Log.e("Clipper", "write", e);
        }
    }

    private void closeClip() {
        if (clipOut == null) return;
        try { clipOut.close(); } catch (IOException ignored) {}
        clipOut = null;
        clipSeconds = 0;

        final File pcm = clipPcm;
        final long startMs = clipStartMs;
        final long endMs = lastSpeechMs;
        final long durMs = clipFrames * FRAME_MS;
        if (clipSpeechFrames * FRAME_MS / 1000 < MIN_SPEECH_SECONDS) {
            pcm.delete();
            return;
        }
        encoder.execute(() -> {
            String name = "clip_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(startMs)) + ".m4a";
            File tmp = new File(getCacheDir(), name);
            try {
                AacEncoder.encode(pcm, tmp, SAMPLE_RATE, BITRATE);
                Uri uri = ClipStore.save(this, tmp, name, durMs);
                clipsToday++;
                notifyClip(this, uri, name, durMs / 1000, startMs, endMs);
            } catch (Exception e) {
                Log.e("Clipper", "save clip", e);
            } finally {
                pcm.delete();
                tmp.delete();
            }
        });
    }

    // ------------------------------------------------------------ notifications

    static void createChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel rec = new NotificationChannel(CH_REC, "Listening", NotificationManager.IMPORTANCE_LOW);
        rec.setShowBadge(false);
        nm.createNotificationChannel(rec);

        NotificationChannel clips = new NotificationChannel(CH_CLIPS, "New clips", NotificationManager.IMPORTANCE_DEFAULT);
        clips.setSound(null, null);
        clips.enableVibration(true);
        clips.setVibrationPattern(new long[]{0, 120});
        nm.createNotificationChannel(clips);
        Schedule.createChannel(c);
    }

    private static Notification.Action action(Context c, int icon, String title, PendingIntent pi) {
        return new Notification.Action.Builder(Icon.createWithResource(c, icon), title, pi).build();
    }

    private PendingIntent serviceIntent(String action, int code) {
        return PendingIntent.getService(this, code,
                new Intent(this, RecorderService.class).setAction(action), PendingIntent.FLAG_IMMUTABLE);
    }

    private String ongoingText() {
        switch (state) {
            case ARMED:
                return "Ready · starts at " + Schedule.hm(Prefs.officeStart(this));
            case PAUSED:
                long left = Math.max(0, (pausedUntil - System.currentTimeMillis()) / 60_000L);
                return "Paused · resumes in " + (left + 1) + " min";
            case CAPTURING:
                return "Capturing a conversation";
            default:
                return scheduled ? "Listening until " + Schedule.hm(Prefs.officeEnd(this)) : "Listening";
        }
    }

    private Notification ongoingNotification() {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        boolean paused = System.currentTimeMillis() < pausedUntil;
        Notification.Builder b = new Notification.Builder(this, CH_REC)
                .setSmallIcon(R.drawable.ic_stat_clipper)
                .setColor(0xFF2BD4A4)
                .setContentTitle("Clipper")
                .setContentText(ongoingText())
                .setContentIntent(open)
                .setOngoing(true)
                .setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        if (paused) b.addAction(action(this, R.drawable.ic_play, "Resume", serviceIntent(ACTION_RESUME, 2)));
        else b.addAction(action(this, R.drawable.ic_pause, "Pause 30 min", serviceIntent(ACTION_PAUSE, 3)));
        b.addAction(action(this, R.drawable.ic_stop, "Stop", serviceIntent(ACTION_STOP, 1)));
        return b.build();
    }

    private void refreshOngoing() {
        if (!running) return;
        getSystemService(NotificationManager.class).notify(ONGOING_ID, ongoingNotification());
    }

    private void postSummary() {
        int unsent = 0;
        String today = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        for (ClipStore.Clip c : ClipStore.list(this)) {
            if (c.name.startsWith("clip_" + today) && Prefs.sentAt(this, c.name) == 0) unsent++;
        }
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH_CLIPS)
                .setSmallIcon(R.drawable.ic_stat_clipper)
                .setColor(0xFF2BD4A4)
                .setContentTitle("Clipper is off for today")
                .setContentText(unsent == 0 ? "All clips handled." : unsent + " clip" + (unsent == 1 ? "" : "s") + " not sent yet. Tap to review.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        getSystemService(NotificationManager.class).notify(SUMMARY_ID, n);
    }

    static void notifyClip(Context c, Uri uri, String name, long seconds, long startMs, long endMs) {
        int id = name.hashCode();
        SimpleDateFormat hm = new SimpleDateFormat("h:mm a", Locale.US);
        String when = hm.format(new Date(startMs)) + " – " + hm.format(new Date(Math.max(endMs, startMs)));

        PendingIntent send = PendingIntent.getActivity(c, id,
                new Intent(c, ShareActivity.class)
                        .putExtra(ShareActivity.EXTRA_URIS, new String[]{uri.toString()})
                        .putExtra(ShareActivity.EXTRA_NAMES, new String[]{name})
                        .putExtra(ShareActivity.EXTRA_NOTIF, id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent skip = PendingIntent.getBroadcast(c, id,
                new Intent(c, ActionReceiver.class)
                        .setAction(ActionReceiver.ACTION_SKIP)
                        .putExtra(ShareActivity.EXTRA_URIS, new String[]{uri.toString()})
                        .putExtra(ShareActivity.EXTRA_NAMES, new String[]{name})
                        .putExtra(ShareActivity.EXTRA_NOTIF, id),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(c, 0,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(c, CH_CLIPS)
                .setSmallIcon(R.drawable.ic_stat_clipper)
                .setColor(0xFF2BD4A4)
                .setContentTitle("New clip · " + fmt(seconds))
                .setContentText(when)
                .setContentIntent(open)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .addAction(action(c, R.drawable.ic_send, "Send to Gemini", send))
                .addAction(action(c, R.drawable.ic_skip, "Skip", skip))
                .build();
        c.getSystemService(NotificationManager.class).notify(id, n);
    }

    static void pokeTile(Context c) {
        try {
            TileService.requestListeningState(c, new ComponentName(c, ClipperTile.class));
        } catch (Exception ignored) {}
    }

    static String fmt(long seconds) {
        long m = seconds / 60, s = seconds % 60;
        return m > 0 ? m + " min " + s + " s" : s + " s";
    }
}
