package com.siva.clipper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Listens all day. Keeps only stretches where someone is speaking, groups them
 * into one clip per conversation, and when a conversation ends (a long silence)
 * turns the clip into a small .m4a and shows a "Send to Gemini / Skip" notification.
 */
public class RecorderService extends Service {
    static final String ACTION_START = "com.siva.clipper.START";
    static final String ACTION_STOP = "com.siva.clipper.STOP";

    static final String CH_REC = "rec";
    static final String CH_CLIPS = "clips";
    static final int ONGOING_ID = 1;

    static final int SAMPLE_RATE = 16000;
    private static final int FRAME = 480;              // 30 ms at 16 kHz
    private static final int FRAME_MS = 30;
    private static final int PREROLL_FRAMES = 34;      // ~1 s kept before speech starts
    private static final int HANGOVER_FRAMES = 50;     // ~1.5 s kept after speech stops
    private static final int TRIGGER_FRAMES = 3;       // ~90 ms of sound before we call it speech
    private static final int MIN_CLIP_SECONDS = 5;     // shorter clips are thrown away
    private static final int BITRATE = 32000;          // ~14 MB per hour of speech

    static volatile boolean running = false;
    static volatile String status = "Stopped";

    private Thread worker;
    private final ExecutorService encoder = Executors.newSingleThreadExecutor();
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            running = false;
            status = "Stopping…";
            if (worker == null) stopSelfNow();
            return START_NOT_STICKY;
        }
        if (worker != null) return START_NOT_STICKY;

        try {
            startForeground(ONGOING_ID, ongoingNotification("Listening"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } catch (Exception e) {
            status = "Could not start: open Clipper and tap Start";
            stopSelf();
            return START_NOT_STICKY;
        }

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clipper:rec");
        wakeLock.acquire();

        running = true;
        worker = new Thread(this::recordLoop, "clipper-rec");
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        encoder.shutdown();
        super.onDestroy();
    }

    private void stopSelfNow() {
        if (!status.startsWith("Could") && !status.startsWith("Microphone")) status = "Stopped";
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    // ---------------------------------------------------------------- recording

    private FileOutputStream clipOut;
    private File clipPcm;
    private long clipStartMs;
    private long clipFrames;        // frames written (speech + padding)
    private long clipSpeechFrames;  // frames judged as speech
    private long lastSpeechMs;
    private String lastNotified = "";

    private void recordLoop() {
        int minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord rec;
        try {
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minBuf, SAMPLE_RATE * 2));
        } catch (SecurityException e) {
            status = "Microphone permission missing";
            running = false;
            finishLoop();
            return;
        }
        if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
            status = "Could not open the microphone";
            rec.release();
            running = false;
            finishLoop();
            return;
        }

        rec.startRecording();
        short[] frame = new short[FRAME];
        byte[] bytes = new byte[FRAME * 2];
        ArrayDeque<byte[]> preroll = new ArrayDeque<>();
        double noise = 200;
        int speechRun = 0;
        int hang = 0;
        long lastStatusMs = 0;

        while (running) {
            int n = readFully(rec, frame);
            if (n < 0) break;
            long now = System.currentTimeMillis();

            // Loudness of this 30 ms frame.
            double sum = 0;
            for (short s : frame) sum += (double) s * s;
            double rms = Math.sqrt(sum / FRAME);

            int sens = Prefs.sensitivity(this);
            double mult = sens == 0 ? 4.0 : sens == 1 ? 2.8 : 2.0;
            double minAbs = sens == 0 ? 500 : sens == 1 ? 300 : 180;
            boolean loud = rms > Math.max(noise * mult, minAbs);

            if (!loud) {
                // Track the room's background hum so fans/AC don't count as speech.
                double rate = rms < noise ? 0.05 : 0.005;
                noise = noise * (1 - rate) + rms * rate;
                if (noise < 30) noise = 30;
            }
            speechRun = loud ? speechRun + 1 : 0;
            boolean speech = speechRun >= TRIGGER_FRAMES;

            toBytes(frame, bytes);

            if (speech) {
                hang = HANGOVER_FRAMES;
                lastSpeechMs = now;
                if (clipOut == null) openClip(now);
                if (clipOut != null) {
                    while (!preroll.isEmpty()) write(preroll.pollFirst());
                    clipSpeechFrames++;
                }
            }

            if (clipOut != null && hang > 0) {
                write(bytes);
                hang--;
            } else {
                preroll.addLast(bytes.clone());
                if (preroll.size() > PREROLL_FRAMES) preroll.pollFirst();
            }

            if (clipOut != null) {
                long gapMs = Prefs.gapSeconds(this) * 1000L;
                long maxFrames = Prefs.maxClipMinutes(this) * 60_000L / FRAME_MS;
                if ((hang == 0 && now - lastSpeechMs > gapMs) || clipSpeechFrames >= maxFrames) {
                    closeClip();
                    hang = 0;
                }
            }

            if (now - lastStatusMs > 1000) {
                lastStatusMs = now;
                String st = clipOut == null
                        ? "Listening · waiting for speech"
                        : "Capturing · " + fmt(clipSpeechFrames * FRAME_MS / 1000) + " of speech so far";
                // Live mic meter for the app screen, so you can see it hears you.
                int bars = (int) Math.min(10, Math.round(rms / Math.max(noise, 1) * 2));
                status = st + "\nMic: " + "▮▮▮▮▮▮▮▮▮▮".substring(0, Math.max(1, bars)) + (loud ? "  (speech)" : "");
                if (!st.equals(lastNotified)) {
                    lastNotified = st;
                    updateOngoing(st);
                }
            }
        }

        try { rec.stop(); } catch (Exception ignored) {}
        rec.release();
        finishLoop();
    }

    /** Runs on the worker thread when listening ends. */
    private void finishLoop() {
        closeClip();
        encoder.execute(() -> {
            worker = null;
            stopSelfNow();
        });
    }

    private static int readFully(AudioRecord rec, short[] buf) {
        int off = 0;
        while (off < buf.length) {
            int n = rec.read(buf, off, buf.length - off);
            if (n < 0) return n;
            off += n;
        }
        return off;
    }

    private static void toBytes(short[] s, byte[] b) {
        for (int i = 0; i < s.length; i++) {
            b[2 * i] = (byte) (s[i] & 0xff);
            b[2 * i + 1] = (byte) ((s[i] >> 8) & 0xff);
        }
    }

    private void openClip(long now) {
        try {
            clipStartMs = now;
            clipFrames = 0;
            clipSpeechFrames = 0;
            clipPcm = new File(getCacheDir(), "clip_" + now + ".pcm");
            clipOut = new FileOutputStream(clipPcm);
        } catch (IOException e) {
            Log.e("Clipper", "open clip", e);
            clipOut = null;
        }
    }

    private void write(byte[] b) {
        try {
            clipOut.write(b);
            clipFrames++;
        } catch (IOException e) {
            Log.e("Clipper", "write", e);
        }
    }

    private void closeClip() {
        if (clipOut == null) return;
        try { clipOut.close(); } catch (IOException ignored) {}
        clipOut = null;

        final File pcm = clipPcm;
        final long startMs = clipStartMs;
        final long endMs = lastSpeechMs;
        final int seconds = (int) (clipFrames * FRAME_MS / 1000);
        if (seconds < MIN_CLIP_SECONDS) {
            pcm.delete();
            return;
        }
        encoder.execute(() -> {
            String name = "clip_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(startMs)) + ".m4a";
            File out = new File(Prefs.clipsDir(this), name);
            try {
                AacEncoder.encode(pcm, out, SAMPLE_RATE, BITRATE);
                notifyClip(this, out, seconds, startMs, endMs);
            } catch (Exception e) {
                Log.e("Clipper", "encode", e);
                out.delete();
            } finally {
                pcm.delete();
            }
        });
    }

    // ------------------------------------------------------------ notifications

    static void createChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel rec = new NotificationChannel(CH_REC, "Listening", NotificationManager.IMPORTANCE_LOW);
        rec.setShowBadge(false);
        nm.createNotificationChannel(rec);

        NotificationChannel clips = new NotificationChannel(CH_CLIPS, "New clips", NotificationManager.IMPORTANCE_DEFAULT);
        clips.setSound(null, null);
        clips.enableVibration(true);
        clips.setVibrationPattern(new long[]{0, 120});
        nm.createNotificationChannel(clips);
    }

    private Notification ongoingNotification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, RecorderService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CH_REC)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Clipper")
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .build();
    }

    private void updateOngoing(String text) {
        if (!running) return;
        getSystemService(NotificationManager.class).notify(ONGOING_ID, ongoingNotification(text));
    }

    static void notifyClip(Context c, File clip, int seconds, long startMs, long endMs) {
        int id = clip.getName().hashCode();
        SimpleDateFormat hm = new SimpleDateFormat("h:mm a", Locale.US);
        String when = hm.format(new Date(startMs)) + "–" + hm.format(new Date(Math.max(endMs, startMs)));

        PendingIntent send = PendingIntent.getActivity(c, id,
                new Intent(c, ShareActivity.class)
                        .putExtra(ShareActivity.EXTRA_PATH, clip.getAbsolutePath())
                        .putExtra(ShareActivity.EXTRA_NOTIF, id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent skip = PendingIntent.getBroadcast(c, id,
                new Intent(c, ActionReceiver.class)
                        .setAction(ActionReceiver.ACTION_SKIP)
                        .putExtra(ShareActivity.EXTRA_PATH, clip.getAbsolutePath())
                        .putExtra(ShareActivity.EXTRA_NOTIF, id),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(c, 0,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(c, CH_CLIPS)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("New clip · " + fmt(seconds) + " of speech")
                .setContentText(when)
                .setContentIntent(open)
                .setAutoCancel(true)
                .addAction(new Notification.Action.Builder(null, "Send to Gemini", send).build())
                .addAction(new Notification.Action.Builder(null, "Skip", skip).build())
                .build();
        c.getSystemService(NotificationManager.class).notify(id, n);
    }

    static String fmt(long seconds) {
        long m = seconds / 60, s = seconds % 60;
        return m > 0 ? m + " min " + s + " s" : s + " s";
    }
}
