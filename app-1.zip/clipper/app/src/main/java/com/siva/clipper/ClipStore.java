package com.siva.clipper;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Clips live in the phone's shared "Recordings/Clipper" folder, so they show up in
 * the Files app and in Gemini's file picker. Only Clipper's own files are listed.
 */
final class ClipStore {
    private ClipStore() {}

    static final class Clip {
        final Uri uri;
        final String name;
        final long addedMs;
        final long sizeBytes;
        long durationMs;

        Clip(Uri uri, String name, long addedMs, long sizeBytes, long durationMs) {
            this.uri = uri;
            this.name = name;
            this.addedMs = addedMs;
            this.sizeBytes = sizeBytes;
            this.durationMs = durationMs;
        }

        /** Start time is encoded in the name: clip_yyyyMMdd_HHmmss.m4a */
        long startMs() {
            try {
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US);
                return f.parse(name.substring(5, 20)).getTime();
            } catch (Exception e) {
                return addedMs;
            }
        }
    }

    static String folder() {
        String base = Build.VERSION.SDK_INT >= 31 ? Environment.DIRECTORY_RECORDINGS : Environment.DIRECTORY_MUSIC;
        return base + "/Clipper/";
    }

    private static Uri collection() {
        return MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
    }

    /** Copies a finished .m4a into Recordings/Clipper and returns its Uri. */
    static Uri save(Context c, File m4a, String name, long durationMs) throws Exception {
        ContentResolver cr = c.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder());
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        v.put(MediaStore.Audio.Media.IS_MUSIC, 0);
        Uri uri = cr.insert(collection(), v);
        if (uri == null) throw new IllegalStateException("Could not create file in " + folder());
        try (InputStream in = new FileInputStream(m4a); OutputStream out = cr.openOutputStream(uri)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (Exception e) {
            cr.delete(uri, null, null);
            throw e;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        done.put(MediaStore.Audio.Media.DURATION, durationMs);
        cr.update(uri, done, null, null);
        return uri;
    }

    /** Clipper's clips, newest first. */
    static List<Clip> list(Context c) {
        List<Clip> out = new ArrayList<>();
        String[] cols = {
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.MediaColumns.SIZE,
                MediaStore.Audio.Media.DURATION,
        };
        String sel = MediaStore.MediaColumns.RELATIVE_PATH + "=? AND "
                + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE 'clip_%'";
        try (Cursor cur = c.getContentResolver().query(collection(), cols, sel,
                new String[]{folder()}, MediaStore.MediaColumns.DISPLAY_NAME + " DESC")) {
            if (cur == null) return out;
            while (cur.moveToNext()) {
                long id = cur.getLong(0);
                out.add(new Clip(ContentUris.withAppendedId(collection(), id),
                        cur.getString(1), cur.getLong(2) * 1000L, cur.getLong(3), cur.getLong(4)));
            }
        } catch (Exception e) {
            Log.e("Clipper", "list clips", e);
        }
        return out;
    }

    static long duration(Context c, Clip clip) {
        if (clip.durationMs > 0) return clip.durationMs;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(c, clip.uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            clip.durationMs = d == null ? 0 : Long.parseLong(d);
        } catch (Exception ignored) {
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
        return clip.durationMs;
    }

    static boolean delete(Context c, Uri uri, String name) {
        try {
            int n = c.getContentResolver().delete(uri, null, null);
            if (name != null) Prefs.forget(c, name);
            return n > 0;
        } catch (Exception e) {
            Log.e("Clipper", "delete", e);
            return false;
        }
    }

    /** Removes clips that were sent to Gemini more than N days ago. */
    static void cleanup(Context c) {
        int days = Prefs.autoDeleteDays(c);
        if (days <= 0) return;
        long cutoff = System.currentTimeMillis() - days * 86_400_000L;
        for (Clip clip : list(c)) {
            long sent = Prefs.sentAt(c, clip.name);
            if (sent > 0 && sent < cutoff) delete(c, clip.uri, clip.name);
        }
    }
}
