package com.siva.clipper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    static final String EXTRA_AUTOSTART = "autostart";
    private static final int MAX_BATCH = 10;

    private final Handler ui = new Handler(Looper.getMainLooper());

    // status card
    private View dot;
    private TextView stateTitle, stateSub, errorText, scheduleLine;
    private LevelView meter;
    private LinearLayout buttonRow, fixesRow;
    private String lastButtonsKey = "";

    // clips
    private LinearLayout clipList;
    private TextView clipsHeader, selectToggle;
    private boolean selecting = false;
    private final Set<String> selected = new LinkedHashSet<>();
    private List<ClipStore.Clip> clips = new ArrayList<>();
    private String clipsSignature = "";

    // bottom bar for batch actions
    private LinearLayout bottomBar;
    private TextView batchSend;

    // settings
    private EditText promptBox;
    private TextView officeStartBtn, officeEndBtn;

    // playback
    private MediaPlayer player;
    private Uri playing;

    private int pendingStart = 0; // 0 none, 1 all day, 2 office hours
    private int tick = 0;
    private int insetBottom = 0;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            updateStatus();
            if (++tick % 25 == 0) refreshClips(false);
            ui.postDelayed(this, 100);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        RecorderService.createChannels(this);
        Schedule.scheduleNext(this);
        new Thread(() -> ClipStore.cleanup(this)).start();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 16);
        content.setPadding(pad, pad, pad, Ui.dp(this, 96));
        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        buildHeader(content);
        buildStatusCard(content);
        buildClips(content);
        buildSettings(content);
        buildBottomBar(root);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            insetBottom = bottom;
            scroll.setPadding(0, top, 0, bottom);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) bottomBar.getLayoutParams();
            lp.bottomMargin = bottom + Ui.dp(this, 12);
            bottomBar.setLayoutParams(lp);
            return insets;
        });
        setContentView(root);

        if (getIntent().getBooleanExtra(EXTRA_AUTOSTART, false)) smartStart();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getBooleanExtra(EXTRA_AUTOSTART, false)) smartStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshClips(true);
        ui.post(loop);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(loop);
        String p = promptBox.getText().toString().trim();
        Prefs.setPrompt(this, p.isEmpty() ? Prefs.DEFAULT_PROMPT : promptBox.getText().toString());
    }

    @Override
    protected void onDestroy() {
        stopPlayback();
        super.onDestroy();
    }

    // ================================================================== header

    private void buildHeader(LinearLayout parent) {
        TextView title = Ui.text(this, "Clipper", 30, Ui.TEXT, true);
        title.setPadding(Ui.dp(this, 4), Ui.dp(this, 8), 0, 0);
        parent.addView(title);
        scheduleLine = Ui.text(this, "", 13, Ui.MUTED, false);
        scheduleLine.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), 0, Ui.dp(this, 4));
        parent.addView(scheduleLine);
        updateScheduleLine();
    }

    private void updateScheduleLine() {
        String hours = Schedule.hm(Prefs.officeStart(this)) + " – " + Schedule.hm(Prefs.officeEnd(this));
        scheduleLine.setText("Office hours " + hours + "  ·  " + (Prefs.morningAsk(this)
                ? "asks at 6 AM on working days" : "morning question off"));
    }

    // ============================================================= status card

    private void buildStatusCard(LinearLayout parent) {
        LinearLayout card = Ui.card(this);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        dot = new View(this);
        int ds = Ui.dp(this, 12);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ds, ds);
        dlp.rightMargin = Ui.dp(this, 10);
        top.addView(dot, dlp);
        stateTitle = Ui.text(this, "Off", 24, Ui.TEXT, true);
        top.addView(stateTitle);
        card.addView(top);

        stateSub = Ui.text(this, "", 14, Ui.MUTED, false);
        stateSub.setPadding(Ui.dp(this, 22), Ui.dp(this, 2), 0, 0);
        card.addView(stateSub);

        meter = new LevelView(this);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 64));
        mlp.topMargin = Ui.dp(this, 16);
        mlp.bottomMargin = Ui.dp(this, 4);
        card.addView(meter, mlp);

        TextView legend = Ui.text(this, "Teal = voice  ·  Grey = other sound (ignored)", 12, Ui.MUTED, false);
        legend.setGravity(Gravity.CENTER);
        card.addView(legend, new LinearLayout.LayoutParams(-1, -2));

        errorText = Ui.text(this, "", 13, Ui.RED, false);
        errorText.setPadding(0, Ui.dp(this, 8), 0, 0);
        errorText.setVisibility(View.GONE);
        card.addView(errorText);

        buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.topMargin = Ui.dp(this, 16);
        card.addView(buttonRow, blp);

        fixesRow = new LinearLayout(this);
        fixesRow.setOrientation(LinearLayout.VERTICAL);
        card.addView(fixesRow);

        parent.addView(card);
    }

    private void addButton(LinearLayout row, TextView b, boolean first) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (!first) lp.leftMargin = Ui.dp(this, 10);
        row.addView(b, lp);
    }

    private void updateStatus() {
        RecorderService.State st = RecorderService.running ? RecorderService.state : RecorderService.State.OFF;
        int color;
        String title, sub;
        switch (st) {
            case ARMED:
                color = Ui.AMBER; title = "Ready";
                sub = "Starts listening at " + Schedule.hm(Prefs.officeStart(this));
                break;
            case LISTENING:
                color = Ui.ACCENT; title = "Listening";
                sub = RecorderService.scheduled ? "Until " + Schedule.hm(Prefs.officeEnd(this)) : "Until you stop it";
                break;
            case CAPTURING:
                color = Ui.RED; title = "Capturing";
                sub = "Conversation · " + RecorderService.fmt(RecorderService.clipSeconds);
                break;
            case PAUSED:
                color = Ui.AMBER; title = "Paused";
                long left = Math.max(0, (RecorderService.pausedUntil - System.currentTimeMillis()) / 60_000L) + 1;
                sub = "Resumes in " + left + " min";
                break;
            default:
                color = 0xFF4A5060; title = "Off";
                sub = Prefs.morningAsk(this) ? "I'll ask at 6 AM on working days" : "Tap a Start button to listen";
        }
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        if (st == RecorderService.State.CAPTURING) {
            dot.setAlpha(0.55f + 0.45f * (float) Math.abs(Math.sin(System.currentTimeMillis() / 400.0)));
        } else {
            dot.setAlpha(1f);
        }
        dot.setBackground(g);
        stateTitle.setText(title);
        stateSub.setText(sub);

        boolean live = st == RecorderService.State.LISTENING || st == RecorderService.State.CAPTURING;
        if (live) meter.push(RecorderService.level, RecorderService.voiceNow, RecorderService.noiseNow);
        else meter.push(0, false, false);

        String err = RecorderService.error;
        errorText.setVisibility(err == null ? View.GONE : View.VISIBLE);
        if (err != null) errorText.setText(err);

        boolean running = RecorderService.running;
        boolean paused = st == RecorderService.State.PAUSED;
        String key = running + "/" + paused;
        if (!key.equals(lastButtonsKey)) {
            lastButtonsKey = key;
            buttonRow.removeAllViews();
            if (!running) {
                TextView office = Ui.pill(this, "Start · office hours", Ui.ACCENT, true);
                office.setOnClickListener(v -> requestStart(2));
                TextView allDay = Ui.pill(this, "All day", Ui.ACCENT, false);
                allDay.setOnClickListener(v -> requestStart(1));
                addButton(buttonRow, office, true);
                addButton(buttonRow, allDay, false);
            } else {
                TextView pause = Ui.pill(this, paused ? "Resume" : "Pause 30 min", Ui.AMBER, false);
                pause.setOnClickListener(v -> startService(new Intent(this, RecorderService.class)
                        .setAction(paused ? RecorderService.ACTION_RESUME : RecorderService.ACTION_PAUSE)));
                TextView stop = Ui.pill(this, "Stop", Ui.RED, false);
                stop.setOnClickListener(v -> startService(new Intent(this, RecorderService.class)
                        .setAction(RecorderService.ACTION_STOP)));
                addButton(buttonRow, pause, true);
                addButton(buttonRow, stop, false);
            }
            updateFixes();
        }
        if (tick % 20 == 0) updateFixes();
    }

    /** Shows one-tap fixes for settings that would stop Clipper working well. */
    private void updateFixes() {
        fixesRow.removeAllViews();
        boolean notifOff = !getSystemService(NotificationManager.class).areNotificationsEnabled();
        boolean batteryOff = !((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
        if (notifOff) {
            TextView t = Ui.pill(this, "Turn on notifications (needed for clips)", Ui.AMBER, false);
            t.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
            addFix(t);
        }
        if (batteryOff) {
            TextView t = Ui.pill(this, "Allow running in background", Ui.AMBER, false);
            t.setOnClickListener(v -> askBatteryExemption());
            addFix(t);
        }
    }

    private void addFix(TextView t) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 10);
        fixesRow.addView(t, lp);
    }

    // ============================================================ start / stop

    /** From the Quick Settings tile: office hours on working days, otherwise all day. */
    private void smartStart() {
        if (RecorderService.running) return;
        boolean workday = !Schedule.isBankHoliday(Calendar.getInstance())
                && Schedule.nowMinutes() < Prefs.officeEnd(this);
        requestStart(workday ? 2 : 1);
    }

    private void requestStart(int mode) {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) {
            pendingStart = mode;
            requestPermissions(need.toArray(new String[0]), 1);
            return;
        }
        startRecorder(mode);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        int mode = pendingStart;
        pendingStart = 0;
        if (mode == 0) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecorder(mode);
        } else {
            Toast.makeText(this, "Microphone permission is needed to listen", Toast.LENGTH_LONG).show();
        }
    }

    private void startRecorder(int mode) {
        if (mode == 2 && Schedule.nowMinutes() >= Prefs.officeEnd(this)) {
            Toast.makeText(this, "Office hours are over for today. Use All day instead.", Toast.LENGTH_LONG).show();
            return;
        }
        RecorderService.error = null;
        startForegroundService(new Intent(this, RecorderService.class)
                .setAction(mode == 2 ? RecorderService.ACTION_ARM : RecorderService.ACTION_START));
    }

    private void askBatteryExemption() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    // =================================================================== clips

    private void buildClips(LinearLayout parent) {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(this, 4), Ui.dp(this, 22), Ui.dp(this, 4), Ui.dp(this, 2));
        clipsHeader = Ui.text(this, "Clips", 20, Ui.TEXT, true);
        head.addView(clipsHeader, new LinearLayout.LayoutParams(0, -2, 1));
        selectToggle = Ui.text(this, "Select", 15, Ui.ACCENT, true);
        selectToggle.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
        selectToggle.setOnClickListener(v -> {
            selecting = !selecting;
            selected.clear();
            refreshClips(true);
        });
        head.addView(selectToggle);
        parent.addView(head);

        TextView where = Ui.text(this, "Saved in " + ClipStore.folder().replaceAll("/$", "")
                + " · also in Gemini's + → Files", 12, Ui.MUTED, false);
        where.setPadding(Ui.dp(this, 4), 0, 0, Ui.dp(this, 2));
        parent.addView(where);

        clipList = new LinearLayout(this);
        clipList.setOrientation(LinearLayout.VERTICAL);
        parent.addView(clipList);
    }

    private void refreshClips(boolean force) {
        List<ClipStore.Clip> fresh = ClipStore.list(this);
        StringBuilder sig = new StringBuilder();
        for (ClipStore.Clip c : fresh) sig.append(c.name).append(Prefs.sentAt(this, c.name) > 0 ? "s" : "u").append(';');
        if (!force && sig.toString().equals(clipsSignature)) return;
        clipsSignature = sig.toString();
        clips = fresh;

        // Drop selections for clips that no longer exist.
        Set<String> names = new LinkedHashSet<>();
        for (ClipStore.Clip c : clips) names.add(c.name);
        selected.retainAll(names);

        int unsent = 0;
        for (ClipStore.Clip c : clips) if (Prefs.sentAt(this, c.name) == 0) unsent++;
        clipsHeader.setText(clips.isEmpty() ? "Clips" : "Clips  ·  " + unsent + " to send");
        selectToggle.setText(selecting ? "Done" : "Select");
        selectToggle.setVisibility(clips.isEmpty() ? View.GONE : View.VISIBLE);

        clipList.removeAllViews();
        if (clips.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            TextView t = Ui.text(this, "No clips yet. Each conversation becomes a clip here and a notification on your phone and watch.", 14, Ui.MUTED, false);
            empty.addView(t);
            clipList.addView(empty);
        } else {
            String lastDay = "";
            for (ClipStore.Clip c : clips) {
                String day = dayLabel(c.startMs());
                if (!day.equals(lastDay)) {
                    clipList.addView(Ui.label(this, day));
                    lastDay = day;
                }
                clipList.addView(clipCard(c));
            }
        }
        updateBottomBar();
    }

    private View clipCard(ClipStore.Clip c) {
        boolean sent = Prefs.sentAt(this, c.name) > 0;
        boolean isSel = selected.contains(c.name);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 12);
        card.setPadding(p, p, p, p);
        card.setBackground(Ui.round(isSel ? 0xFF1C3A33 : Ui.CARD, Ui.dp(this, 18)));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.topMargin = Ui.dp(this, 8);
        card.setLayoutParams(clp);

        boolean isPlaying = c.uri.equals(playing);
        ImageButton play = Ui.iconButton(this, isPlaying ? R.drawable.ic_stop : R.drawable.ic_play,
                isPlaying ? Ui.RED : Ui.TEXT, Ui.CARD_HI);
        play.setOnClickListener(v -> togglePlay(c));
        card.addView(play);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        SimpleDateFormat hm = new SimpleDateFormat("h:mm a", Locale.US);
        texts.addView(Ui.text(this, hm.format(new Date(c.startMs())), 16, Ui.TEXT, true));
        long secs = ClipStore.duration(this, c) / 1000;
        String meta = String.format(Locale.US, "%d:%02d  ·  %.1f MB", secs / 60, secs % 60, c.sizeBytes / 1_048_576.0);
        LinearLayout metaRow = new LinearLayout(this);
        metaRow.addView(Ui.text(this, meta, 13, Ui.MUTED, false));
        if (sent) {
            TextView s = Ui.text(this, "  ·  Sent ✓", 13, Ui.ACCENT, true);
            metaRow.addView(s);
        }
        texts.addView(metaRow);
        card.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        if (selecting) {
            TextView check = Ui.text(this, isSel ? "✓" : "", 18, 0xFF0B0D10, true);
            check.setGravity(Gravity.CENTER);
            GradientDrawable box = Ui.round(isSel ? Ui.ACCENT : 0x00000000, Ui.dp(this, 8));
            if (!isSel) box.setStroke(Ui.dp(this, 2), Ui.MUTED);
            check.setBackground(box);
            int s = Ui.dp(this, 28);
            card.addView(check, new LinearLayout.LayoutParams(s, s));
            card.setOnClickListener(v -> {
                if (selected.contains(c.name)) selected.remove(c.name);
                else if (selected.size() < MAX_BATCH) selected.add(c.name);
                else Toast.makeText(this, "Gemini takes up to " + MAX_BATCH + " files at once", Toast.LENGTH_SHORT).show();
                refreshClips(true);
            });
        } else {
            ImageButton send = Ui.iconButton(this, R.drawable.ic_send, Ui.ACCENT, Ui.CARD_HI);
            send.setOnClickListener(v -> sendClips(java.util.Collections.singletonList(c)));
            card.addView(send);
            ImageButton del = Ui.iconButton(this, R.drawable.ic_skip, Ui.MUTED, Ui.CARD_HI);
            LinearLayout.LayoutParams dlp = (LinearLayout.LayoutParams) del.getLayoutParams();
            dlp.leftMargin = Ui.dp(this, 8);
            del.setOnClickListener(v -> {
                if (c.uri.equals(playing)) stopPlayback();
                ClipStore.delete(this, c.uri, c.name);
                refreshClips(true);
            });
            card.addView(del);
            card.setOnLongClickListener(v -> {
                selecting = true;
                selected.clear();
                selected.add(c.name);
                refreshClips(true);
                return true;
            });
        }
        return card;
    }

    private String dayLabel(long ms) {
        Calendar a = Calendar.getInstance();
        Calendar d = Calendar.getInstance();
        d.setTimeInMillis(ms);
        if (sameDay(a, d)) return "Today";
        a.add(Calendar.DAY_OF_MONTH, -1);
        if (sameDay(a, d)) return "Yesterday";
        return new SimpleDateFormat("EEE, d MMM", Locale.US).format(new Date(ms));
    }

    private static boolean sameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }

    private void sendClips(List<ClipStore.Clip> list) {
        if (list.isEmpty()) return;
        ArrayList<Uri> uris = new ArrayList<>();
        String[] names = new String[list.size()];
        // Oldest first, so Gemini reads them in time order.
        List<ClipStore.Clip> ordered = new ArrayList<>(list);
        ordered.sort((x, y) -> x.name.compareTo(y.name));
        for (int i = 0; i < ordered.size(); i++) {
            uris.add(ordered.get(i).uri);
            names[i] = ordered.get(i).name;
            getSystemService(NotificationManager.class).cancel(ordered.get(i).name.hashCode());
        }
        ShareActivity.sendToGemini(this, uris, names);
        selecting = false;
        selected.clear();
        clipsSignature = "";
    }

    // ============================================================ batch actions

    private void buildBottomBar(FrameLayout root) {
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackground(Ui.round(Ui.CARD_HI, Ui.dp(this, 28)));
        int p = Ui.dp(this, 8);
        bottomBar.setPadding(p, p, p, p);
        bottomBar.setElevation(Ui.dp(this, 8));

        batchSend = Ui.pill(this, "Send", Ui.ACCENT, true);
        batchSend.setOnClickListener(v -> {
            List<ClipStore.Clip> pick = new ArrayList<>();
            for (ClipStore.Clip c : clips) if (selected.contains(c.name)) pick.add(c);
            sendClips(pick);
        });
        TextView del = Ui.pill(this, "Delete", Ui.RED, false);
        del.setOnClickListener(v -> new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Delete " + selected.size() + " clip" + (selected.size() == 1 ? "" : "s") + "?")
                .setPositiveButton("Delete", (d, w) -> {
                    for (ClipStore.Clip c : clips) {
                        if (selected.contains(c.name)) {
                            if (c.uri.equals(playing)) stopPlayback();
                            ClipStore.delete(this, c.uri, c.name);
                        }
                    }
                    selected.clear();
                    selecting = false;
                    refreshClips(true);
                })
                .setNegativeButton("Cancel", null)
                .show());
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 2);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, -2, 1);
        b2.leftMargin = Ui.dp(this, 8);
        bottomBar.addView(batchSend, a);
        bottomBar.addView(del, b2);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        int m = Ui.dp(this, 16);
        lp.leftMargin = m;
        lp.rightMargin = m;
        lp.bottomMargin = m;
        root.addView(bottomBar, lp);
        bottomBar.setVisibility(View.GONE);
    }

    private void updateBottomBar() {
        boolean show = selecting && !selected.isEmpty();
        bottomBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) batchSend.setText("Send " + selected.size() + " to Gemini");
    }

    // ================================================================ playback

    private void togglePlay(ClipStore.Clip c) {
        if (c.uri.equals(playing)) {
            stopPlayback();
        } else {
            stopPlayback();
            player = MediaPlayer.create(this, c.uri);
            if (player == null) {
                Toast.makeText(this, "Can't play this clip", Toast.LENGTH_SHORT).show();
                return;
            }
            playing = c.uri;
            player.setOnCompletionListener(mp -> { stopPlayback(); refreshClips(true); });
            player.start();
        }
        refreshClips(true);
    }

    private void stopPlayback() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
        playing = null;
    }

    // ================================================================ settings

    private void buildSettings(LinearLayout parent) {
        TextView h = Ui.text(this, "Settings", 20, Ui.TEXT, true);
        h.setPadding(Ui.dp(this, 4), Ui.dp(this, 26), 0, 0);
        parent.addView(h);

        // ---- listening
        LinearLayout listen = Ui.card(this);
        listen.addView(Ui.text(this, "Listening", 16, Ui.TEXT, true));
        listen.addView(Ui.label(this, "Sensitivity"));
        listen.addView(Ui.segmented(this, new String[]{"Low", "Medium", "High"},
                Prefs.sensitivity(this), i -> Prefs.setSensitivity(this, i)));
        listen.addView(hint("Low favours voices close to the phone."));

        listen.addView(Ui.label(this, "A conversation ends after this much silence"));
        final int[] gaps = {60, 90, 120, 180};
        listen.addView(Ui.segmented(this, new String[]{"1 min", "1.5", "2", "3 min"},
                indexOf(gaps, Prefs.gapSeconds(this), 1), i -> Prefs.setGapSeconds(this, gaps[i])));

        listen.addView(Ui.label(this, "Longest clip"));
        final int[] maxes = {5, 10, 15, 20};
        listen.addView(Ui.segmented(this, new String[]{"5 min", "10", "15", "20 min"},
                indexOf(maxes, Prefs.maxClipMinutes(this), 1), i -> Prefs.setMaxClipMinutes(this, maxes[i])));
        parent.addView(listen);

        // ---- schedule
        LinearLayout sched = Ui.card(this);
        sched.addView(Ui.text(this, "Working days", 16, Ui.TEXT, true));
        sched.addView(hint("Sundays and 2nd/4th Saturdays are skipped. On other days I ask at 6 AM; tap No on holidays."));

        LinearLayout askRow = new LinearLayout(this);
        askRow.setGravity(Gravity.CENTER_VERTICAL);
        askRow.setPadding(0, Ui.dp(this, 12), 0, 0);
        askRow.addView(Ui.text(this, "Ask \"Working day today?\" at 6 AM", 15, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(Prefs.morningAsk(this));
        sw.setOnCheckedChangeListener((btn, on) -> {
            Prefs.setMorningAsk(this, on);
            Schedule.scheduleNext(this);
            updateScheduleLine();
        });
        askRow.addView(sw);
        sched.addView(askRow);

        sched.addView(Ui.label(this, "Office hours"));
        LinearLayout hours = new LinearLayout(this);
        officeStartBtn = Ui.pill(this, Schedule.hm(Prefs.officeStart(this)), Ui.TEXT, false);
        officeEndBtn = Ui.pill(this, Schedule.hm(Prefs.officeEnd(this)), Ui.TEXT, false);
        officeStartBtn.setOnClickListener(v -> pickTime(true));
        officeEndBtn.setOnClickListener(v -> pickTime(false));
        hours.addView(officeStartBtn, new LinearLayout.LayoutParams(0, -2, 1));
        TextView to = Ui.text(this, "to", 14, Ui.MUTED, false);
        to.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
        hours.setGravity(Gravity.CENTER_VERTICAL);
        hours.addView(to);
        hours.addView(officeEndBtn, new LinearLayout.LayoutParams(0, -2, 1));
        sched.addView(hours);

        TextView test = Ui.text(this, "Show the morning question now (test)", 14, Ui.ACCENT, true);
        test.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 2));
        test.setOnClickListener(v -> Schedule.ask(this));
        sched.addView(test);
        parent.addView(sched);

        // ---- housekeeping
        LinearLayout house = Ui.card(this);
        house.addView(Ui.text(this, "Housekeeping", 16, Ui.TEXT, true));
        house.addView(Ui.label(this, "Delete clips after they're sent"));
        final int[] days = {1, 3, 7, 0};
        house.addView(Ui.segmented(this, new String[]{"1 day", "3 days", "7 days", "Never"},
                indexOf(days, Prefs.autoDeleteDays(this), 1), i -> Prefs.setAutoDeleteDays(this, days[i])));
        house.addView(hint("Unsent clips are never deleted automatically."));
        parent.addView(house);

        // ---- prompt
        LinearLayout pr = Ui.card(this);
        pr.addView(Ui.text(this, "Prompt sent to Gemini", 16, Ui.TEXT, true));
        promptBox = new EditText(this);
        promptBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        promptBox.setMinLines(3);
        promptBox.setTextColor(Ui.TEXT);
        promptBox.setTextSize(14);
        promptBox.setBackground(Ui.round(Ui.CARD_HI, Ui.dp(this, 12)));
        int pp = Ui.dp(this, 12);
        promptBox.setPadding(pp, pp, pp, pp);
        promptBox.setText(Prefs.prompt(this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = Ui.dp(this, 10);
        pr.addView(promptBox, plp);
        TextView reset = Ui.text(this, "Reset to default", 14, Ui.ACCENT, true);
        reset.setPadding(0, Ui.dp(this, 12), 0, 0);
        reset.setOnClickListener(v -> promptBox.setText(Prefs.DEFAULT_PROMPT));
        pr.addView(reset);
        pr.addView(hint("Tip: pick the Gemini 3.1 Pro model when the clip opens in Gemini."));
        parent.addView(pr);

        TextView ver = Ui.text(this, "Clipper " + versionName(), 12, Ui.MUTED, false);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, Ui.dp(this, 20), 0, 0);
        parent.addView(ver, new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView hint(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTED, false);
        t.setPadding(0, Ui.dp(this, 6), 0, 0);
        return t;
    }

    private void pickTime(boolean start) {
        int cur = start ? Prefs.officeStart(this) : Prefs.officeEnd(this);
        new TimePickerDialog(this, android.R.style.Theme_Material_Dialog_Alert, (v, h, m) -> {
            int val = h * 60 + m;
            int s = start ? val : Prefs.officeStart(this);
            int e = start ? Prefs.officeEnd(this) : val;
            if (e <= s) {
                Toast.makeText(this, "End time must be after start time", Toast.LENGTH_SHORT).show();
                return;
            }
            Prefs.setOffice(this, s, e);
            officeStartBtn.setText(Schedule.hm(s));
            officeEndBtn.setText(Schedule.hm(e));
            updateScheduleLine();
        }, cur / 60, cur % 60, false).show();
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private static int indexOf(int[] arr, int v, int fallback) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return fallback;
    }
}
