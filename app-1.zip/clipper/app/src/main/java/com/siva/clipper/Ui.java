package com.siva.clipper;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Tiny helpers for Clipper's dark, card-based look, built in code (no layout files). */
final class Ui {
    static final int BG = 0xFF0F1115;
    static final int CARD = 0xFF191C23;
    static final int CARD_HI = 0xFF232733;
    static final int TEXT = 0xFFECEFF4;
    static final int MUTED = 0xFF8A93A6;
    static final int ACCENT = 0xFF2BD4A4;
    static final int RED = 0xFFFF5C6C;
    static final int AMBER = 0xFFF5B942;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD, dp(c, 20)));
        int p = dp(c, 18);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(c, 12);
        l.setLayoutParams(lp);
        return l;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    static TextView label(Context c, String s) {
        TextView t = text(c, s.toUpperCase(), 12, MUTED, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, dp(c, 14), 0, dp(c, 8));
        return t;
    }

    /** Rounded pill button. filled = accent background, else outlined look. */
    static TextView pill(Context c, String s, int color, boolean filled) {
        TextView b = text(c, s, 15, filled ? 0xFF0B0D10 : color, true);
        b.setGravity(Gravity.CENTER);
        int ph = dp(c, 18), pv = dp(c, 12);
        b.setPadding(ph, pv, ph, pv);
        GradientDrawable g = round(filled ? color : 0x00000000, dp(c, 24));
        if (!filled) g.setStroke(dp(c, 1.5f), color);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), g, null));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    static ImageButton iconButton(Context c, int icon, int tint, int bg) {
        ImageButton b = new ImageButton(c);
        b.setImageResource(icon);
        b.setColorFilter(tint);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(bg);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), circle, null));
        int s = dp(c, 40);
        b.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        int p = dp(c, 9);
        b.setPadding(p, p, p, p);
        b.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        return b;
    }

    interface Pick { void on(int i); }

    /** Segmented control: a row of options, one selected. */
    static LinearLayout segmented(Context c, String[] labels, int selected, Pick pick) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(round(CARD_HI, dp(c, 14)));
        int p = dp(c, 3);
        row.setPadding(p, p, p, p);
        TextView[] items = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            TextView t = text(c, labels[i], 14, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(c, 9), 0, dp(c, 9));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            row.addView(t, lp);
            items[i] = t;
            final int idx = i;
            t.setOnClickListener(v -> {
                styleSeg(c, items, idx);
                pick.on(idx);
            });
        }
        styleSeg(c, items, selected);
        return row;
    }

    private static void styleSeg(Context c, TextView[] items, int sel) {
        for (int i = 0; i < items.length; i++) {
            boolean on = i == sel;
            items[i].setTextColor(on ? 0xFF0B0D10 : MUTED);
            items[i].setBackground(on ? round(ACCENT, dp(c, 11)) : null);
        }
    }

    static View spacer(Context c, int dpH) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, dpH)));
        return v;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0xFF262A34);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(c, 1));
        lp.topMargin = dp(c, 14);
        v.setLayoutParams(lp);
        return v;
    }
}
