package com.siva.clipper;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

/** Invisible screen opened by "Send to Gemini": hands the clip(s) to Gemini and closes. */
public class ShareActivity extends Activity {
    static final String EXTRA_URIS = "uris";
    static final String EXTRA_NAMES = "names";
    static final String EXTRA_NOTIF = "notif";
    static final String GEMINI = "com.google.android.apps.bard";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String[] uris = getIntent().getStringArrayExtra(EXTRA_URIS);
        String[] names = getIntent().getStringArrayExtra(EXTRA_NAMES);
        int notif = getIntent().getIntExtra(EXTRA_NOTIF, 0);
        if (notif != 0) getSystemService(NotificationManager.class).cancel(notif);
        if (uris != null && names != null) {
            ArrayList<Uri> list = new ArrayList<>();
            for (String u : uris) list.add(Uri.parse(u));
            sendToGemini(this, list, names);
        }
        finish();
    }

    static void sendToGemini(Activity a, ArrayList<Uri> uris, String[] names) {
        if (uris.isEmpty()) return;
        String prompt = Prefs.prompt(a);
        if (uris.size() > 1) {
            prompt = "There are " + uris.size() + " separate recordings attached, in time order. "
                    + "Handle each one separately. " + prompt;
        }
        // Backup: if Gemini ignores the attached text, the prompt is ready to paste.
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Clipper prompt", prompt));

        Intent send;
        if (uris.size() == 1) {
            send = new Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            send = new Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        send.setType("audio/mp4")
                .putExtra(Intent.EXTRA_TEXT, prompt)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        ClipData clip = ClipData.newRawUri("clip", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        send.setClipData(clip);

        try {
            a.startActivity(new Intent(send).setPackage(GEMINI));
        } catch (ActivityNotFoundException e) {
            // Gemini didn't accept a direct share; let the user pick it from the share sheet.
            try {
                a.startActivity(Intent.createChooser(send, "Send clip to…")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
            } catch (Exception e2) {
                Toast.makeText(a, "Couldn't open Gemini", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        for (String n : names) Prefs.markSent(a, n);
    }
}
