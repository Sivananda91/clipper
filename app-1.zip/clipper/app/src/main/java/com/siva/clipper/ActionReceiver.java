package com.siva.clipper;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** Handles the "Skip" button: deletes the clip and clears its notification. */
public class ActionReceiver extends BroadcastReceiver {
    static final String ACTION_SKIP = "com.siva.clipper.SKIP";

    @Override
    public void onReceive(Context c, Intent i) {
        if (!ACTION_SKIP.equals(i.getAction())) return;
        String[] uris = i.getStringArrayExtra(ShareActivity.EXTRA_URIS);
        String[] names = i.getStringArrayExtra(ShareActivity.EXTRA_NAMES);
        if (uris != null) {
            for (int k = 0; k < uris.length; k++) {
                ClipStore.delete(c, Uri.parse(uris[k]), names != null && k < names.length ? names[k] : null);
            }
        }
        int notif = i.getIntExtra(ShareActivity.EXTRA_NOTIF, 0);
        if (notif != 0) c.getSystemService(NotificationManager.class).cancel(notif);
    }
}
