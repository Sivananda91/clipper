package com.siva.clipper;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** Small settings store shared by the app's screens, the recorder and the scheduler. */
final class Prefs {
    static final String DEFAULT_PROMPT =
            "Transcribe this office conversation (it may mix English, Telugu and Hindi). "
            + "Then list every commitment, follow-up, deadline and request: "
            + "who said it, what exactly, to whom, and by when. "
            + "If nothing actionable was said, just say so.";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("clipper", Context.MODE_PRIVATE);
    }

    /** 0 = low (close, clear voices), 1 = medium, 2 = high (quieter voices). */
    static int sensitivity(Context c) { return sp(c).getInt("sens", 1); }
    static void setSensitivity(Context c, int v) { sp(c).edit().putInt("sens", v).apply(); }

    /** Silence (seconds) that ends a conversation and closes the clip. */
    static int gapSeconds(Context c) { return sp(c).getInt("gap", 90); }
    static void setGapSeconds(Context c, int v) { sp(c).edit().putInt("gap", v).apply(); }

    /** Longest clip, in minutes of actual audio, before it is closed anyway. */
    static int maxClipMinutes(Context c) { return sp(c).getInt("maxmin", 10); }
    static void setMaxClipMinutes(Context c, int v) { sp(c).edit().putInt("maxmin", v).apply(); }

    static String prompt(Context c) { return sp(c).getString("prompt", DEFAULT_PROMPT); }
    static void setPrompt(Context c, String v) { sp(c).edit().putString("prompt", v).apply(); }

    // ---- office hours & working-day question

    /** Office hours as minutes after midnight. Default 10:00–19:00. */
    static int officeStart(Context c) { return sp(c).getInt("ostart", 10 * 60); }
    static int officeEnd(Context c) { return sp(c).getInt("oend", 19 * 60); }
    static void setOffice(Context c, int start, int end) {
        sp(c).edit().putInt("ostart", start).putInt("oend", end).apply();
    }

    /** Ask "Working day today?" each morning at 6 AM. */
    static boolean morningAsk(Context c) { return sp(c).getBoolean("ask", true); }
    static void setMorningAsk(Context c, boolean v) { sp(c).edit().putBoolean("ask", v).apply(); }

    // ---- housekeeping

    /** Delete clips already sent to Gemini after this many days (0 = never). */
    static int autoDeleteDays(Context c) { return sp(c).getInt("autodel", 3); }
    static void setAutoDeleteDays(Context c, int v) { sp(c).edit().putInt("autodel", v).apply(); }

    /** Names of clips that have been sent to Gemini, with the time they were sent. */
    static void markSent(Context c, String name) {
        sp(c).edit().putLong("sent:" + name, System.currentTimeMillis()).apply();
    }
    static long sentAt(Context c, String name) { return sp(c).getLong("sent:" + name, 0); }
    static void forget(Context c, String name) { sp(c).edit().remove("sent:" + name).apply(); }

    /** Clips that should not be listed or auto-deleted twice. */
    static Set<String> sentNames(Context c) {
        Set<String> out = new HashSet<>();
        for (String k : sp(c).getAll().keySet()) if (k.startsWith("sent:")) out.add(k.substring(5));
        return out;
    }
}
