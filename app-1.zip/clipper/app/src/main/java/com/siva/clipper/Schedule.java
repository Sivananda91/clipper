package com.siva.clipper;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/**
 * Working-day logic.
 *  - Sundays and 2nd/4th Saturdays: bank holidays, Clipper stays off and asks nothing.
 *  - Other days: at 6 AM a notification asks "Working day today?" (Yes / No).
 *  - Yes arms the recorder; it keeps audio only during office hours and switches off after.
 * Public holidays are handled by simply tapping No.
 */
public class Schedule extends BroadcastReceiver {
    static final String ACTION_MORNING = "com.siva.clipper.MORNING";
    static final String ACTION_NO = "com.siva.clipper.NO";
    static final String CH_ASK = "ask";
    static final int ASK_ID = 2;

    /** True for Sundays and the 2nd and 4th Saturdays of the month. */
    static boolean isBankHoliday(Calendar day) {
        int dow = day.get(Calendar.DAY_OF_WEEK);
        if (dow == Calendar.SUNDAY) return true;
        if (dow == Calendar.SATURDAY) {
            int nth = (day.get(Calendar.DAY_OF_MONTH) - 1) / 7 + 1;
            return nth == 2 || nth == 4;
        }
        return false;
    }

    /** Minutes after midnight, now. */
    static int nowMinutes() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    static String hm(int minutes) {
        int h = minutes / 60, m = minutes % 60;
        String ampm = h < 12 ? "AM" : "PM";
        int h12 = h % 12 == 0 ? 12 : h % 12;
        return h12 + ":" + (m < 10 ? "0" : "") + m + " " + ampm;
    }

    /** Sets (or refreshes) the next 6 AM check. Inexact by a few minutes, which needs no special permission. */
    static void scheduleNext(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 10,
                new Intent(c, Schedule.class).setAction(ACTION_MORNING),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        if (!Prefs.morningAsk(c)) {
            am.cancel(pi);
            return;
        }
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, 6);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_MONTH, 1);
        am.setWindow(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), 10 * 60_000L, pi);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (ACTION_NO.equals(a)) {
            c.getSystemService(NotificationManager.class).cancel(ASK_ID);
            return;
        }
        if (ACTION_MORNING.equals(a)) {
            ClipStore.cleanup(c);
            if (!isBankHoliday(Calendar.getInstance()) && nowMinutes() < Prefs.officeEnd(c)) ask(c);
        }
        // Also runs after a reboot or app update, to keep the daily check alive.
        scheduleNext(c);
    }

    static void ask(Context c) {
        createChannel(c);
        PendingIntent yes = PendingIntent.getForegroundService(c, 11,
                new Intent(c, RecorderService.class).setAction(RecorderService.ACTION_ARM),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent no = PendingIntent.getBroadcast(c, 12,
                new Intent(c, Schedule.class).setAction(ACTION_NO),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(c, 13,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

        String hours = hm(Prefs.officeStart(c)) + " – " + hm(Prefs.officeEnd(c));
        Notification n = new Notification.Builder(c, CH_ASK)
                .setSmallIcon(R.drawable.ic_stat_clipper)
                .setContentTitle("Working day today?")
                .setContentText("Yes = Clipper listens during office hours (" + hours + ")")
                .setContentIntent(open)
                .setAutoCancel(true)
                .setColor(0xFF2BD4A4)
                .addAction(new Notification.Action.Builder(null, "Yes", yes).build())
                .addAction(new Notification.Action.Builder(null, "No", no).build())
                .build();
        c.getSystemService(NotificationManager.class).notify(ASK_ID, n);
    }

    static void createChannel(Context c) {
        NotificationChannel ch = new NotificationChannel(CH_ASK, "Morning question", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setSound(null, null);
        c.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }
}
